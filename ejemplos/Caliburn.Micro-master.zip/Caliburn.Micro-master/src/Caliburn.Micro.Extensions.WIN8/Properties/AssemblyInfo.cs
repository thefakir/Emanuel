﻿//using System;
using System.Reflection;
using System.Runtime.InteropServices;
//using System.Windows.Markup;

[assembly: AssemblyTitle("Caliburn Micro Extensions")]
[assembly: AssemblyDescription("Extensions to the core Caliburn.Micro framework.")]

//[assembly: CLSCompliant(true)]
[assembly: ComVisible(false)]
[assembly: Guid("2634F123-71C4-40C8-856D-0E537CF001A6")]

//[assembly: XmlnsDefinition("http://www.caliburnproject.org", "Caliburn.Micro")]
//[assembly: XmlnsPrefix("http://www.caliburnproject.org", "cal")]
