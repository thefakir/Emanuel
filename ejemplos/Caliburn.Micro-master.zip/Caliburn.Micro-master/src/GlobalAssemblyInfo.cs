﻿using System.Reflection;
using System.Resources;

[assembly: AssemblyProduct("Caliburn.Micro")]
[assembly: AssemblyCompany("Blue Spire Consulting, Inc.")]
[assembly: AssemblyCopyright("Copyright © 2010")]

[assembly: NeutralResourcesLanguage("en-US")]

[assembly: AssemblyVersion("2.0.2.0")]
[assembly: AssemblyFileVersion("2.0.2.0")]
