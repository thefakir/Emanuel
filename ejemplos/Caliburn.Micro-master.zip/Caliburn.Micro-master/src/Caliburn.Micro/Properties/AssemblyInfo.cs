﻿using System;
using System.Reflection;

[assembly: AssemblyTitle("Caliburn Micro")]
[assembly: AssemblyDescription("A small, yet powerful framework designed for Xaml platforms, Caliburn.Micro implements a variety of UI patterns for solving real-world problems. Patterns that are highlighted include MVVM (Presentation Model), MVP and MVC.")]

[assembly: CLSCompliant(true)]
