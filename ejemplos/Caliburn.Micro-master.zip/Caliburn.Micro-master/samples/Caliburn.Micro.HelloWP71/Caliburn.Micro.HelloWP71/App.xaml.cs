﻿namespace Caliburn.Micro.HelloWP71 {
    using System.Windows;

    public partial class App : Application {
        public App() {
            InitializeComponent();
        }
    }
}