namespace Caliburn.Micro.HelloScreens.Framework {
    public interface IDocumentWorkspace : IWorkspace {
        void Edit(object document);
    }
}