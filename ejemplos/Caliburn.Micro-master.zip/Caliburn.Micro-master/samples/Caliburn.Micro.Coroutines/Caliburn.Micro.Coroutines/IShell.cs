namespace Caliburn.Micro.Coroutines
{
    public interface IShell : IConductor
    {
        
    }
}