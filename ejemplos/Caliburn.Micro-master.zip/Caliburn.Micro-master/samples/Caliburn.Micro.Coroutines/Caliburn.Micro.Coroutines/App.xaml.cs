﻿namespace Caliburn.Micro.Coroutines
{
    using System.Windows;

    public partial class App : Application
    {
        public App()
        {
            InitializeComponent();
        }
    }
}