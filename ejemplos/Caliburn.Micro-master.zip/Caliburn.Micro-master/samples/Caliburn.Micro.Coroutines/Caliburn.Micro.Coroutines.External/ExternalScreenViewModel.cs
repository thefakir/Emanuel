﻿namespace Caliburn.Micro.Coroutines.External
{
    using System.ComponentModel.Composition;

    [Export("ExternalScreen", typeof(ExternalScreenViewModel))]
    public class ExternalScreenViewModel {}
}