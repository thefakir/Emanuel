﻿using System;

namespace CM.HelloUniversal.Views
{
    public sealed partial class MainView
    {
        public MainView()
        {
            InitializeComponent();
        }
    }
}
