﻿using System.Windows;

namespace Caliburn.Micro.HelloSimpleContainer
{
    public partial class App : Application
    {
        public App()
        {
            InitializeComponent();
        }
    }
}