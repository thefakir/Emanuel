namespace Caliburn.Micro.HelloSimpleContainer
{
    public interface IShell
    {
    }
}