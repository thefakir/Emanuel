namespace Caliburn.Micro.HelloEventAggregator {
    public interface IShell {
        
    }
}