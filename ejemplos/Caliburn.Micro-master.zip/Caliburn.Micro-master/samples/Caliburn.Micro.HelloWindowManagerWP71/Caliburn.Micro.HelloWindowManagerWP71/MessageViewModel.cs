﻿namespace Caliburn.Micro.HelloWindowManagerWP71 {
    public class MessageViewModel : Screen {
        public string Message { get; set; }
    }
}