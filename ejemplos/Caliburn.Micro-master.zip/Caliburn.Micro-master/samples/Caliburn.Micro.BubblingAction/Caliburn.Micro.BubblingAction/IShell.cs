namespace Caliburn.Micro.BubblingAction
{
    public interface IShell
    {
        
    }
}