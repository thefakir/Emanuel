﻿namespace Caliburn.Micro.SimpleMDI {
    public class TabViewModel : Screen {}
}