﻿using System;

namespace Caliburn.Micro.WinRT.Sample.Views
{
    public sealed partial class HubView
    {
        public HubView()
        {
            InitializeComponent();
        }
    }
}
