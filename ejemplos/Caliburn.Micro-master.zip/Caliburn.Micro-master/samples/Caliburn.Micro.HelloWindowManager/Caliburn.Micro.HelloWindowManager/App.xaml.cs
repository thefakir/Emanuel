﻿namespace Caliburn.Micro.HelloWindowManager {
    using System.Windows;

    /// <summary>
    /// Interaction logic for App.xaml
    /// </summary>
    public partial class App : Application {}
}