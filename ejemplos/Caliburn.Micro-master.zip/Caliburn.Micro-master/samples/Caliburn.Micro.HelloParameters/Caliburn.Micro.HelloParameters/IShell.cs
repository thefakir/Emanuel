namespace Caliburn.Micro.HelloParameters
{
    public interface IShell
    {
    }
}