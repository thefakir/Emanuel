﻿using System;

namespace Caliburn.Micro.WinRT.Sample.Views
{
    public sealed partial class SetupView
    {
        public SetupView()
        {
            InitializeComponent();
        }
    }
}
