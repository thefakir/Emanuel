﻿namespace GameLibrary.Model {
    public interface IQuery<TResponse> {}
}