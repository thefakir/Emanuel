﻿namespace GameLibrary.Model {
    public interface ICommand {}
}